module.exports = function(settings, headers) {

    //var value=settings.standard.CANTIDAD,unidad=settings.standard.UNIDAD_ESTANDAR;
    return {
        title: "Module",
        Module: "Module ",
        groupTokensText: "Total tokens of your <b id='group'>&nbsp;</b> group: ",
        myTokensText: "Tokens you have contributed: ",
        // num1: Math.floor(Math.random()*(99-10)+10), // the nubmers are supplied by cb:
        // num2: Math.floor(Math.random()*(99-10)+10),
        linea:"__________",
        proceed: "Submit Answer",
        good: "Correct",
        bad:"Incorrect"
    };
};
/**
 * Created by joseorellana on 01-12-15.
 * Back translated by amatz on 15-02-16.
 */
