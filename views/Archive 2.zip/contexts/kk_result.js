module.exports = function(settings, headers) {

//    var Group = "Klee";//settings.pp.COINS;

//    var groupSize = settings.standard.GROUP_SIZE;

    return {
        title: "Result: Module 1",
        instructions: "Result",
        text : "Based on your choices, you prefer the paintings by <span id='group'>&nbsp;</span>.",
        text2: "You are assigned to <b><span id='group2'>&nbsp;</span></b> group.",
        text3: "The number of people in your <span id='group3'>&nsbp</span> group is <span id='groupSize'>&nbsp;</span>.",
        ifYouUnderstood: "Please press the DONE Button to proceed to the next page."
    };
};
